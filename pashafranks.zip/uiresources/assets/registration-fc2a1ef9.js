import{s as e}from"./index-c5642422.js";const s=e({tempUserId:null,useSteps:[]});export{s as default};
